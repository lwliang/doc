---
title: UI for ASP.NET MVC Public Documentation
publish: false
---

# UI for ASP.NET MVC: Public Documentation

This repository contains the product documentation for the [Progress Telerik<sup>®</sup> UI for ASP.NET MVC suite](http://docs.telerik.com/aspnet-mvc/introduction).

For more information, refer to the [Kendo UI public documentation repository](https://github.com/telerik/kendo/blob/production/docs/README.md).
