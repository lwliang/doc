---
title: Upload Files from Grid Popup Editors
page_title: Upload Files from Grid Popup Editors | Kendo UI Upload HtmlHelper
description: "Upload files from a Grid popup editor in ASP.NET MVC applications."
slug: howto_uploadfilesgridpopupeditor_uploadaspnetmvc
position: 0
---

# Upload Files from Grid Popup Editors

To see the example, refer to the project on how to [upload files from a Grid popup editor](http://www.telerik.com/support/code-library/upload-in-grid-popup-editor).

## See Also

* [Overview of the Upload HtmlHelper]({% slug overview_uploadhelper_aspnetmvc %})
* [UploadBuilder API Reference](http://docs.telerik.com/aspnet-mvc/api/Kendo.Mvc.UI.Fluent/UploadBuilder)

For more runnable examples on the Kendo UI Scheduler in ASP.NET MVC applications, browse its **How To** documentation folder.
