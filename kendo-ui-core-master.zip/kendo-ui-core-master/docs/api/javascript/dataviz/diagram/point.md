---
title: Point
res_type: api
---

# kendo.dataviz.diagram.Point

Represents a point in two-dimensional space.

## Constructor Parameters

### x `Number`

The x coordinate of the point.

### y `Number`

The y coordinate of the point.

## Fields

### x `Number`

The x coordinate of the point.

### y `Number`

The y coordinate of the point.
