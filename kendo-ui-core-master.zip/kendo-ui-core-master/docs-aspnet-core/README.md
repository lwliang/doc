---
title: UI for ASP.NET Core Public Documentation
publish: false
---

# UI for ASP.NET Core: Public Documentation

This repository contains the product documentation for the [Progress Telerik<sup>®</sup> UI for ASP.NET Core suite](http://docs.telerik.com/aspnet-core/introduction).

For more information, refer to the [Kendo UI public documentation repository](https://github.com/telerik/kendo/blob/production/docs/README.md).
